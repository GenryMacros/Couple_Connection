This font are licensed under the SIL Open Font License, Version 1.1.

You can use them freely in your products & projects - print or digital, commercial or otherwise. However, you can't sell the font on their own.

For more information about this font, go to
https://ggbot.itch.io/blackcraft-font
https://www.ggbot.net/fonts